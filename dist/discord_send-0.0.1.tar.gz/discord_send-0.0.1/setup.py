from setuptools import setup, find_packages

setup(
    name="discord_send",
    version="0.0.1",
    packages=find_packages(),
)